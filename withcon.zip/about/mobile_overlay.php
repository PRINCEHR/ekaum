<div class="menu_mobile_overlay">
</div>
<div class="menu_mobile menu_mobile_fullscreen scheme_dark">
<div class="menu_mobile_inner"> <a class="menu_mobile_close icon-cancel">
</a>
<nav class="menu_mobile_nav_area">
<ul id="menu_mobile" class=" menu_mobile_nav">
<li id="menu_mobile-item-151" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-151">
<a href="index.php">
<span>Home</span>
</a>
<ul class="sub-menu">
<li id="menu_mobile-item-336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-336">
<a href="index.php">
<span>Home </span>
</a>
</li>
</ul>
</li>
<!-- <li id="menu_mobile-item-152" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-152">
<a href="#">
<span>Features</span>
</a> -->
<!-- <ul class="sub-menu"> -->
<!-- 
<li id="menu_mobile-item-897" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-897">
<a href="http://ecoplanet.ancorathemes.com/privacy-policy/">
<span>Privacy Policy</span>
</a>
</li> -->
</li>
<li id="menu_mobile-item-159" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-159">
<a href="#">
<span>Gallery</span>
</a>
</li>

<li id="menu_mobile-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338">
<a href="#">
<span>About</span>
</a>
<ul class="sub-menu">
<li id="menu_mobile-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339">
<a href="https://sarvdharm.000webhostapp.com/our-mission/">
<span>Our Mission</span>
</a>
</li>
<li id="menu_mobile-item-340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-340">
<a href="https://sarvdharm.000webhostapp.com/how-we-work/">
<span>How We Work</span>
</a>
</li>
</ul>
</li>
<!-- <li id="menu_mobile-item-268" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-268">
<a href="http://ecoplanet.ancorathemes.com/donation/">
<span>Projects</span>
</a>
</li> -->
<li id="menu_mobile-item-163" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-163">
<a href="blog_christ.php">
<span>Blog</span>
</a>
<!-- <ul class="sub-menu">
<li id="menu_mobile-item-164" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-164">
<a href="#">
<span>Classic</span>
</a> -->

</li>
<!-- <li id="menu_mobile-item-168" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-168">
<a href="#">
<span>Portfolio</span>
</a>
</li>
</ul>
</li> -->
<li id="menu_mobile-item-188" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-176 current_page_item menu-item-188">
<a href="contact.php" aria-current="page">
<span>Contacts</span>
</a>
</li>
</ul>
</nav>

<div class="search_wrap search_style_normal search_mobile">
<div class="search_form_wrap">
<form role="search" method="get" class="search_form" action="https://sarvdharm.000webhostapp.com/"> <input type="text" class="search_field" placeholder="Search" value="" name="s"> <button type="submit" class="search_submit trx_addons_icon-search">
</button>
</form>
</div>
</div>
<div class="socials_mobile">
<a target="_blank" href="https://www.facebook.com/brahmrishishreekumarswami/" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="https://twitter.com/Brahmrishi" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_twitter">
<span class="icon-twitter">
</span>
</span>
</a>
<a target="_blank" href="https://www.instagram.com/brahmrishishreekumarswami/" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
</div>
