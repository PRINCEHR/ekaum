<footer class="footer_wrap footer_default scheme_dark">
<div class="footer_copyright_wrap scheme_">
<div class="footer_copyright_inner">
<div class="content_wrap">
<div class="copyright_text">
<p>
<a href="https://themeforest.net/user/ancorathemes/portfolio" target="_blank">AncoraThemes</a> © 2019. All rights reserved.</p>
</div>
</div>
</div>
</div>
</footer>
<!-- /.footer_wrap -->
</div>
<!-- /.page_wrap -->
</div>
<!-- /.body_wrap --> <script>(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script> <script type="text/javascript">var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;</script> <script type="text/javascript">var wc_product_block_data = JSON.parse( decodeURIComponent( '%7B%22min_columns%22%3A1%2C%22max_columns%22%3A6%2C%22default_columns%22%3A3%2C%22min_rows%22%3A1%2C%22max_rows%22%3A6%2C%22default_rows%22%3A1%2C%22thumbnail_size%22%3A300%2C%22placeholderImgSrc%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fwp-content%5C%2Fuploads%5C%2Fwoocommerce-placeholder.png%22%2C%22min_height%22%3A500%2C%22default_height%22%3A500%2C%22isLargeCatalog%22%3Afalse%2C%22limitTags%22%3Afalse%2C%22hasTags%22%3Atrue%2C%22productCategories%22%3A%5B%7B%22term_id%22%3A58%2C%22name%22%3A%22Uncategorized%22%2C%22slug%22%3A%22uncategorized%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A58%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fproduct-category%5C%2Funcategorized%5C%2F%22%7D%2C%7B%22term_id%22%3A26%2C%22name%22%3A%22Backpack%22%2C%22slug%22%3A%22backpack%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A26%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A1%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fproduct-category%5C%2Fbackpack%5C%2F%22%7D%2C%7B%22term_id%22%3A27%2C%22name%22%3A%22Blouse%22%2C%22slug%22%3A%22blouse%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A27%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A1%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fproduct-category%5C%2Fblouse%5C%2F%22%7D%2C%7B%22term_id%22%3A23%2C%22name%22%3A%22Longsleeve%22%2C%22slug%22%3A%22longsleeve%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A23%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A1%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fproduct-category%5C%2Flongsleeve%5C%2F%22%7D%2C%7B%22term_id%22%3A25%2C%22name%22%3A%22T-Shirt%22%2C%22slug%22%3A%22t-shirt%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A25%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fproduct-category%5C%2Ft-shirt%5C%2F%22%7D%2C%7B%22term_id%22%3A24%2C%22name%22%3A%22Top%22%2C%22slug%22%3A%22top%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A24%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A1%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2Fproduct-category%5C%2Ftop%5C%2F%22%7D%5D%2C%22homeUrl%22%3A%22http%3A%5C%2F%5C%2Fecoplanet.ancorathemes.com%5C%2F%22%7D' ) );</script> <link property="stylesheet" rel='stylesheet' id='font-awesome-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=6.0.1' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='slick-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/vc-extensions-bundle/draggabletimeline/../testimonialcarousel/slick/slick.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='perfect-scrollbar-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/vc-extensions-bundle/draggabletimeline/css/perfect-scrollbar.min.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='vc-extensions-draggabletimeline-style-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/vc-extensions-bundle/draggabletimeline/css/style.css?ver=5.2.2' type='text/css' media='all' /> <script type='text/javascript'>/* <![CDATA[ */
var TRX_ADDONS_STORAGE = {"ajax_url":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","ajax_nonce":"ad20bf7fa9","site_url":"http:\/\/ecoplanet.ancorathemes.com","post_id":"304","vc_edit_mode":"0","popup_engine":"magnific","animate_inner_links":"0","user_logged_in":"0","email_mask":"^([a-zA-Z0-9_\\-]+\\.)*[a-zA-Z0-9_\\-]+@[a-z0-9_\\-]+(\\.[a-z0-9_\\-]+)*\\.[a-z]{2,6}$","msg_ajax_error":"Invalid server answer!","msg_magnific_loading":"Loading image","msg_magnific_error":"Error loading image","msg_error_like":"Error saving your like! Please, try again later.","msg_field_name_empty":"The name can't be empty","msg_field_email_empty":"Too short (or empty) email address","msg_field_email_not_valid":"Invalid email address","msg_field_text_empty":"The message text can't be empty","msg_search_error":"Search error! Try again later.","msg_send_complete":"Send message complete!","msg_send_error":"Transmit failed!","ajax_views":"","menu_cache":[".menu_mobile_inner > nav > ul"],"login_via_ajax":"1","msg_login_empty":"The Login field can't be empty","msg_login_long":"The Login field is too long","msg_password_empty":"The password can't be empty and shorter then 4 characters","msg_password_long":"The password is too long","msg_login_success":"Login success! The page should be reloaded in 3 sec.","msg_login_error":"Login failed!","msg_not_agree":"Please, read and check 'Terms and Conditions'","msg_email_long":"E-mail address is too long","msg_email_not_valid":"E-mail address is invalid","msg_password_not_equal":"The passwords in both fields are not equal","msg_registration_success":"Registration success! Please log in!","msg_registration_error":"Registration failed!","scroll_to_anchor":"1","update_location_from_anchor":"0","msg_sc_googlemap_not_avail":"Googlemap service is not available","msg_sc_googlemap_geocoder_error":"Error while geocode address"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_d2c6a3b64e555ee9404ded5267cc587b","fragment_name":"wc_fragments_d2c6a3b64e555ee9404ded5267cc587b","request_timeout":"5000"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var wpgdprcData = {"ajaxURL":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","ajaxSecurity":"a92808b1d1","isMultisite":"","path":"\/","blogId":""};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var GREEN_PLANET_STORAGE = {"ajax_url":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","ajax_nonce":"ad20bf7fa9","site_url":"http:\/\/ecoplanet.ancorathemes.com","site_scheme":"scheme_default","user_logged_in":"","mobile_layout_width":"767","mobile_device":"","menu_side_stretch":"1","menu_side_icons":"1","background_video":"","use_mediaelements":"1","comment_maxlength":"1000","admin_mode":"","email_mask":"^([a-zA-Z0-9_\\-]+\\.)*[a-zA-Z0-9_\\-]+@[a-z0-9_\\-]+(\\.[a-z0-9_\\-]+)*\\.[a-z]{2,6}$","strings":{"ajax_error":"Invalid server answer!","error_global":"Error data validation!","name_empty":"The name can&#039;t be empty","name_long":"Too long name","email_empty":"Too short (or empty) email address","email_long":"Too long email address","email_not_valid":"Invalid email address","text_empty":"The message text can&#039;t be empty","text_long":"Too long message text"},"alter_link_color":"#e1a932","button_hover":"default"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */</script> <!--[if lte IE 9]> <script type='text/javascript' src='http://ecoplanet.ancorathemes.com/wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.5.3'>
</script> <![endif]--> <a href="#" class="trx_addons_scroll_to_top trx_addons_icon-up" title="Scroll to top">
</a> <script type="text/javascript" defer src="http://ecoplanet.ancorathemes.com/wp-content/cache/autoptimize/js/autoptimize_68d24337e3544147d15eccc828ed5566.js">
</script>
</body>
</html>