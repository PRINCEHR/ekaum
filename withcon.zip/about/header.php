
<!DOCTYPE html>
<html lang="en-US" class="no-js scheme_default">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta name="format-detection" content="telephone=no">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="http://ecoplanet.ancorathemes.com/xmlrpc.php">
<title>Our Mission &#8211; Green Planet</title>
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Green Planet &raquo; Feed" href="http://ecoplanet.ancorathemes.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Green Planet &raquo; Comments Feed" href="http://ecoplanet.ancorathemes.com/comments/feed/" /> <script type="text/javascript">window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/ecoplanet.ancorathemes.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.2.2"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);</script> <style type="text/css">img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}</style>
<link property="stylesheet" rel='stylesheet' id='vc_extensions_cqbundle_adminicon-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/vc-extensions-bundle/css/admin_icon.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='wp-block-library-css'  href='http://ecoplanet.ancorathemes.com/wp-includes/css/dist/block-library/style.min.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='wc-block-style-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=2.3.0' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='essential-grid-plugin-settings-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/essential-grid/public/assets/css/settings.css?ver=2.3.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='tp-open-sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300%2C400%2C600%2C700%2C800&#038;ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='tp-raleway-css'  href='http://fonts.googleapis.com/css?family=Raleway%3A100%2C200%2C300%2C400%2C500%2C600%2C700%2C800%2C900&#038;ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='tp-droid-serif-css'  href='http://fonts.googleapis.com/css?family=Droid+Serif%3A400%2C700&#038;ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='tp-fontello-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/essential-grid/public/assets/font/fontello/css/fontello.css?ver=2.3.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='rs-plugin-settings-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.4.8.3' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>#rs-demo-id {}</style>
<link property="stylesheet" rel='stylesheet' id='trx_addons-icons-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/trx_addons/css/font-icons/css/trx_addons_icons-embedded.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='swiperslider-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/trx_addons/js/swiper/swiper.min.css' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='magnific-popup-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/trx_addons/js/magnific/magnific-popup.min.css' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='trx_addons-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/trx_addons/css/trx_addons.css' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='trx_addons-animation-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/trx_addons/css/trx_addons.animation.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='woocommerce-layout-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=3.7.0' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=3.7.0' type='text/css' media='only screen and (max-width: 768px)' />
<link property="stylesheet" rel='stylesheet' id='woocommerce-general-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.7.0' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>.woocommerce form .form-row .required { visibility: visible; }</style>
<!--[if lt IE 9]>
<link property="stylesheet" rel='stylesheet' id='vc_lte_ie9-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css?ver=6.0.1' type='text/css' media='screen' /> <![endif]-->
<link property="stylesheet" rel='stylesheet' id='js_composer_front-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.0.1' type='text/css' media='all' />
<style id='js_composer_front-inline-css' type='text/css'>.vc_custom_1492690670304{padding-top: 8rem !important;}.vc_custom_1494506273996{padding-top: 6.6rem !important;padding-bottom: 7.5em !important;}.vc_custom_1494506278348{margin-top: -9.5em !important;padding-bottom: 7.5em !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/grey_pattern.png?id=641) !important;}.vc_custom_1493892601642{padding-top: 8.5em !important;padding-bottom: 8.65em !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_noise.jpg?id=292) !important;}.vc_custom_1492687903312{padding-top: 5.5rem !important;padding-bottom: 9.4rem !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_cta.jpg?id=341) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1492690519932{padding-top: 6.45rem !important;padding-bottom: 5.6rem !important;}.vc_custom_1492682789454{margin-bottom: 3rem !important;}.vc_custom_1493025760097{margin-top: 3rem !important;}.vc_custom_1503995930984{margin-top: 3rem !important;}</style>
<link property="stylesheet" rel='stylesheet' id='wpgdprc.css-css'  href='http://ecoplanet.ancorathemes.com/wp-content/plugins/wp-gdpr-compliance/assets/css/front.css?ver=1558475857' type='text/css' media='all' />
<style id='wpgdprc.css-inline-css' type='text/css'>div.wpgdprc .wpgdprc-switch .wpgdprc-switch-inner:before { content: 'Yes'; }
            div.wpgdprc .wpgdprc-switch .wpgdprc-switch-inner:after { content: 'No'; }</style>
<link property="stylesheet" rel='stylesheet' id='green_planet-font-google_fonts-css'  href='http://fonts.googleapis.com/css?family=Playfair+Display%3APlayfair+Display%3A400%2C700%2C700i%7CMontserrat%3AMontserrat%3A400%2C500%2C700%7CDroid+Serif%3ADroid+Serif%3A400%2C700&#038;subset=latin%2Clatin-ext&#038;ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='fontello-css'  href='http://ecoplanet.ancorathemes.com/wp-content/themes/green-planet/css/fontello/css/fontello-embedded.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='green_planet-main-css'  href='http://ecoplanet.ancorathemes.com/wp-content/themes/green-planet/style.css' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='green_planet-styles-css'  href='http://ecoplanet.ancorathemes.com/wp-content/themes/green-planet/css/__styles.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='green_planet-colors-css'  href='http://ecoplanet.ancorathemes.com/wp-content/themes/green-planet/css/__colors.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='mediaelement-css'  href='http://ecoplanet.ancorathemes.com/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css?ver=4.2.6-78496d1' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='wp-mediaelement-css'  href='http://ecoplanet.ancorathemes.com/wp-includes/js/mediaelement/wp-mediaelement.min.css?ver=5.2.2' type='text/css' media='all' />
<link property="stylesheet" rel='stylesheet' id='green_planet-responsive-css'  href='http://ecoplanet.ancorathemes.com/wp-content/themes/green-planet/css/responsive.css?ver=5.2.2' type='text/css' media='all' /> <script type='text/javascript' src='http://ecoplanet.ancorathemes.com/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp'>
</script> <script type='text/javascript'>/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/ecoplanet.ancorathemes.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */</script> <script type='text/javascript'>var mejsL10n = {"language":"en","strings":{"mejs.install-flash":"You are using a browser that does not have Flash player enabled or installed. Please turn on your Flash player plugin or download the latest version from https:\/\/get.adobe.com\/flashplayer\/","mejs.fullscreen-off":"Turn off Fullscreen","mejs.fullscreen-on":"Go Fullscreen","mejs.download-video":"Download Video","mejs.fullscreen":"Fullscreen","mejs.time-jump-forward":["Jump forward 1 second","Jump forward %1 seconds"],"mejs.loop":"Toggle Loop","mejs.play":"Play","mejs.pause":"Pause","mejs.close":"Close","mejs.time-slider":"Time Slider","mejs.time-help-text":"Use Left\/Right Arrow keys to advance one second, Up\/Down arrows to advance ten seconds.","mejs.time-skip-back":["Skip back 1 second","Skip back %1 seconds"],"mejs.captions-subtitles":"Captions\/Subtitles","mejs.captions-chapters":"Chapters","mejs.none":"None","mejs.mute-toggle":"Mute Toggle","mejs.volume-help-text":"Use Up\/Down Arrow keys to increase or decrease volume.","mejs.unmute":"Unmute","mejs.mute":"Mute","mejs.volume-slider":"Volume Slider","mejs.video-player":"Video Player","mejs.audio-player":"Audio Player","mejs.ad-skip":"Skip ad","mejs.ad-skip-info":["Skip in 1 second","Skip in %1 seconds"],"mejs.source-chooser":"Source Chooser","mejs.stop":"Stop","mejs.speed-rate":"Speed Rate","mejs.live-broadcast":"Live Broadcast","mejs.afrikaans":"Afrikaans","mejs.albanian":"Albanian","mejs.arabic":"Arabic","mejs.belarusian":"Belarusian","mejs.bulgarian":"Bulgarian","mejs.catalan":"Catalan","mejs.chinese":"Chinese","mejs.chinese-simplified":"Chinese (Simplified)","mejs.chinese-traditional":"Chinese (Traditional)","mejs.croatian":"Croatian","mejs.czech":"Czech","mejs.danish":"Danish","mejs.dutch":"Dutch","mejs.english":"English","mejs.estonian":"Estonian","mejs.filipino":"Filipino","mejs.finnish":"Finnish","mejs.french":"French","mejs.galician":"Galician","mejs.german":"German","mejs.greek":"Greek","mejs.haitian-creole":"Haitian Creole","mejs.hebrew":"Hebrew","mejs.hindi":"Hindi","mejs.hungarian":"Hungarian","mejs.icelandic":"Icelandic","mejs.indonesian":"Indonesian","mejs.irish":"Irish","mejs.italian":"Italian","mejs.japanese":"Japanese","mejs.korean":"Korean","mejs.latvian":"Latvian","mejs.lithuanian":"Lithuanian","mejs.macedonian":"Macedonian","mejs.malay":"Malay","mejs.maltese":"Maltese","mejs.norwegian":"Norwegian","mejs.persian":"Persian","mejs.polish":"Polish","mejs.portuguese":"Portuguese","mejs.romanian":"Romanian","mejs.russian":"Russian","mejs.serbian":"Serbian","mejs.slovak":"Slovak","mejs.slovenian":"Slovenian","mejs.spanish":"Spanish","mejs.swahili":"Swahili","mejs.swedish":"Swedish","mejs.tagalog":"Tagalog","mejs.thai":"Thai","mejs.turkish":"Turkish","mejs.ukrainian":"Ukrainian","mejs.vietnamese":"Vietnamese","mejs.welsh":"Welsh","mejs.yiddish":"Yiddish"}};</script> <script type='text/javascript'>/* <![CDATA[ */
var _wpmejsSettings = {"pluginPath":"\/wp-includes\/js\/mediaelement\/","classPrefix":"mejs-","stretching":"responsive"};
/* ]]> */</script> <link rel='https://api.w.org/' href='http://ecoplanet.ancorathemes.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://ecoplanet.ancorathemes.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://ecoplanet.ancorathemes.com/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 5.2.2" />
<meta name="generator" content="WooCommerce 3.7.0" />
<link rel="canonical" href="http://ecoplanet.ancorathemes.com/our-mission/" />
<link rel='shortlink' href='http://ecoplanet.ancorathemes.com/?p=304' />
<link rel="alternate" type="application/json+oembed" href="http://ecoplanet.ancorathemes.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fecoplanet.ancorathemes.com%2Four-mission%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://ecoplanet.ancorathemes.com/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fecoplanet.ancorathemes.com%2Four-mission%2F&#038;format=xml" /> <script type="text/javascript">var ajaxRevslider;
			
			jQuery(document).ready(function() {
				// CUSTOM AJAX CONTENT LOADING FUNCTION
				ajaxRevslider = function(obj) {
				
					// obj.type : Post Type
					// obj.id : ID of Content to Load
					// obj.aspectratio : The Aspect Ratio of the Container / Media
					// obj.selector : The Container Selector where the Content of Ajax will be injected. It is done via the Essential Grid on Return of Content
					
					var content = "";

					data = {};
					
					data.action = 'revslider_ajax_call_front';
					data.client_action = 'get_slider_html';
					data.token = '8296417e3f';
					data.type = obj.type;
					data.id = obj.id;
					data.aspectratio = obj.aspectratio;
					
					// SYNC AJAX REQUEST
					jQuery.ajax({
						type:"post",
						url:"http://ecoplanet.ancorathemes.com/wp-admin/admin-ajax.php",
						dataType: 'json',
						data:data,
						async:false,
						success: function(ret, textStatus, XMLHttpRequest) {
							if(ret.success == true)
								content = ret.data;								
						},
						error: function(e) {
							console.log(e);
						}
					});
					
					 // FIRST RETURN THE CONTENT WHEN IT IS LOADED !!
					 return content;						 
				};
				
				// CUSTOM AJAX FUNCTION TO REMOVE THE SLIDER
				var ajaxRemoveRevslider = function(obj) {
					return jQuery(obj.selector+" .rev_slider").revkill();
				};

				// EXTEND THE AJAX CONTENT LOADING TYPES WITH TYPE AND FUNCTION
				var extendessential = setInterval(function() {
					if (jQuery.fn.tpessential != undefined) {
						clearInterval(extendessential);
						if(typeof(jQuery.fn.tpessential.defaults) !== 'undefined') {
							jQuery.fn.tpessential.defaults.ajaxTypes.push({type:"revslider",func:ajaxRevslider,killfunc:ajaxRemoveRevslider,openAnimationSpeed:0.3});   
							// type:  Name of the Post to load via Ajax into the Essential Grid Ajax Container
							// func: the Function Name which is Called once the Item with the Post Type has been clicked
							// killfunc: function to kill in case the Ajax Window going to be removed (before Remove function !
							// openAnimationSpeed: how quick the Ajax Content window should be animated (default is 0.3)
						}
					}
				},30);
			});</script> <noscript>
<style>.woocommerce-product-gallery{ opacity: 1 !important; }</style>
</noscript>
<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 5.4.8.3 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." /> <script type="text/javascript">function setREVStartSize(e){									
						try{ e.c=jQuery(e.c);var i=jQuery(window).width(),t=9999,r=0,n=0,l=0,f=0,s=0,h=0;
							if(e.responsiveLevels&&(jQuery.each(e.responsiveLevels,function(e,f){f>i&&(t=r=f,l=e),i>f&&f>r&&(r=f,n=e)}),t>r&&(l=n)),f=e.gridheight[l]||e.gridheight[0]||e.gridheight,s=e.gridwidth[l]||e.gridwidth[0]||e.gridwidth,h=i/s,h=h>1?1:h,f=Math.round(h*f),"fullscreen"==e.sliderLayout){var u=(e.c.width(),jQuery(window).height());if(void 0!=e.fullScreenOffsetContainer){var c=e.fullScreenOffsetContainer.split(",");if (c) jQuery.each(c,function(e,i){u=jQuery(i).length>0?u-jQuery(i).outerHeight(!0):u}),e.fullScreenOffset.split("%").length>1&&void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0?u-=jQuery(window).height()*parseInt(e.fullScreenOffset,0)/100:void 0!=e.fullScreenOffset&&e.fullScreenOffset.length>0&&(u-=parseInt(e.fullScreenOffset,0))}f=u}else void 0!=e.minHeight&&f<e.minHeight&&(f=e.minHeight);e.c.closest(".rev_slider_wrapper").css({height:f})					
						}catch(d){console.log("Failure at Presize of Slider:"+d)}						
					};</script> <noscript>
<style type="text/css">.wpb_animate_when_almost_visible { opacity: 1; }</style>
</noscript>
<style type="text/css" id="trx_addons-inline-styles-inline-css">.vc_custom_1504017395840{padding-top: 9.3em !important;padding-bottom: 10.4em !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/04/bg_pages.jpg?id=869) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}.vc_custom_1494237196387{margin-left: 1em !important;}.vc_custom_1492673866902{background-color: #a1c643 !important;}.vc_custom_1492674233429{margin-top: 2.4rem !important;}.vc_custom_1491492610034{padding-top: 4.8rem !important;padding-bottom: 5rem !important;background-image: url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/bg_newsletter.jpg?id=182) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}</style>

</head>