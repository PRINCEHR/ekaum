<?php include "header.php"
?>
<body class="page-template-default page page-id-304 theme-green-planet woocommerce-no-js body_tag scheme_default blog_mode_page body_style_wide is_single sidebar_hide expand_content remove_margins header_style_header-custom-452 header_position_default menu_style_top no_layout wpb-js-composer js-comp-ver-6.0.1 vc_responsive">
<div class="body_wrap">
<div class="page_wrap">
<header class="top_panel top_panel_custom top_panel_custom_452 top_panel_custom_header-1 without_bg_image scheme_default">
<div class="vc_row wpb_row vc_row-fluid vc_row-o-content-middle vc_row-flex sc_layouts_row sc_layouts_row_type_normal sc_layouts_row_fixed">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div id="sc_content_1420049565"
 class="sc_content sc_content_default sc_float_center sc_content_width_1_1">
<div class="sc_content_container">
<div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-middle vc_row-flex">
<div class="wpb_column vc_column_container vc_col-sm-3 sc_layouts_column sc_layouts_column_align_left sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<?php include "nav_bar.php"
?>
<!-- /.sc_content -->
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid title_breadrumbs_block vc_custom_1504017395840 vc_row-has-fill scheme_dark">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div id="sc_content_292507671"
 class="sc_content sc_content_default sc_float_center sc_content_width_1_1">
<div class="sc_content_container">
<div class="vc_row wpb_row vc_inner vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="sc_layouts_item">
<div id="sc_layouts_title_2016428017" class="sc_layouts_title">
<div class="sc_layouts_title_title">
<h1 class="sc_layouts_title_caption">Our Mission</h1>
</div>
<div class="sc_layouts_title_breadcrumbs">
<div class="breadcrumbs">
<a class="breadcrumbs_item home" href="http://ecoplanet.ancorathemes.com/">Home</a>
<span class="breadcrumbs_delimiter">
</span>
<span class="breadcrumbs_item current">Our Mission</span>
</div>
</div>
</div>
<!-- /.sc_layouts_title -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- /.sc_content -->
</div>
</div>
</div>
</div>
</header>
<?php include "mobile_overlay.php"
?>
<div class="page_content_wrap scheme_default">
<div class="content_wrap">
<div class="content">
<article id="post-304" class="post_item_single post_type_page post-304 page type-page status-publish hentry">
<div class="post_content entry-content">
<div class="vc_row wpb_row vc_row-fluid vc_custom_1492690670304">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="sc_layouts sc_layouts_default sc_layouts_303">
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="sc_layouts_item">
<div  id="sc_promo_995837406" 
 class="sc_promo sc_promo_default  vc_custom_1492673866902 sc_promo_size_normal sc_promo_image_position_left">
<div class="sc_promo_image" style="background-image:url(http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/img_mission.jpg);width:50%;left: 0;">
</div>
<div class="sc_promo_text sc_float_center" style="width: 50%;float: right;">
<div class="sc_promo_text_inner sc_align_center" style="">
<div class="sc_promo_content sc_item_content">
<div class="wpb_text_column wpb_content_element " >
<div class="wpb_wrapper">
<h3 style="text-align: center; margin-bottom: 2rem;">
<span style="color: #ffffff;">
<em style="text-transform: capitalize;">Our</em> Mission</span>
</h3>
<p>
<span style="background-color: white; color: #a1c643; width: 52px; height: 2px; display: block; overflow: hidden; margin: 0 auto 2.1rem;">line</span>
</p>
<p style="text-align: center;">
<span style="color: #ffffff;">Better ecology, clean water source</span>
<br /> <span style="color: #ffffff;"> an animal living freely within its healthy</span>
<br /> <span style="color: #ffffff;"> environment, always.</span>
</p>
</div>
</div>
<div class="sc_layouts_item">
<div class="sc_item_button sc_button_wrap sc_align_center">
<a href="/how-we-work/" id="sc_button_330721480" class="sc_button sc_button_white  vc_custom_1492674233429 sc_button_size_large sc_button_icon_left">
<span class="sc_button_text">
<span class="sc_button_title">more about us</span>
</span>
<!-- /.sc_button_text -->
</a>
<!-- /.sc_button -->
</div>
<!-- /.sc_item_button -->
</div>
</div>
</div>
</div>
<!-- /.sc_promo_text -->
</div>
<!-- /.sc_promo -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid hide_on_mobile vc_custom_1494506273996">
<div class="wpb_column vc_column_container vc_col-sm-2 vc_col-lg-2 vc_col-md-2 vc_hidden-sm vc_hidden-xs sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-8 vc_col-md-8 vc_col-xs-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div id="sc_title_804647947"
 class="sc_title sc_title_default  vc_custom_1492682789454">
<h2 class="sc_item_title sc_title_title sc_align_center sc_item_title_style_default">Our History</h2>
<h6 class="sc_item_subtitle sc_title_subtitle sc_align_center sc_item_title_style_default">join us!</h6>
<div class="sc_item_descr sc_title_descr sc_align_center">
<p>Donec fringilla, justo quam sodales a vehicula ipsum libero eget mi Integer condimentum, nibh aliquet fringilla. Donec fringilla.</p>
</div>
</div>
<!-- /.sc_title -->
<div class="cq-draggable-container empty_icon" data-draggingbarbgcolor="rgba(0, 0, 0, 0.5)" data-defaultbarbgcolor="" data-avatarstyle="icon" data-activeiconcolor="" data-autoplay="no" data-autoplayspeed="" data-labelcolor="" data-dragbuttonwidth="" data-contaienrwidth="75%">
<div class="cq-draggable-slider">
<div class="cq-draggable-stripe">
<div class="cq-draggable-handle">
<div class="cq-infobox gray">
<div class="cq-titlecontainer">
</div>
<div class="cq-innerbox">
<div class="cq-carouselcontainer">
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.</div>
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.</div>
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.</div>
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.</div>
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.</div>
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.</div>
<div class="cq-carouselcontent">Lorem ipsum dolor sit amet, consectetuer adipi.<p>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="cq-barcontainer">
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2002 </span>
</div>
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2003 </span>
</div>
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2007 </span>
</div>
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2009 </span>
</div>
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2012 </span>
</div>
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2014 </span>
</div>
<div class="cq-highlight-container icon">
<div class="cq-highlight round" data-iconbgcolors="">
<span class="fa fa-1x fa-empty">
</span>
</div>
<span class="cq-highlight-label">2016 </span>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-3 vc_col-lg-2 vc_col-md-2 vc_hidden-sm vc_hidden-xs sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
</div>
<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid hide_on_mobile vc_custom_1494506278348 vc_row-has-fill">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
</div>
<div class="vc_row-full-width vc_clearfix">
</div>
<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1493892601642 vc_row-has-fill">
<div class="wpb_column vc_column_container vc_col-sm-5 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div id="sc_title_1048668550"
 class="sc_title sc_title_default">
<h2 class="sc_item_title sc_title_title sc_align_left sc_item_title_style_default">Team of Experts</h2>
<h6 class="sc_item_subtitle sc_title_subtitle sc_align_left sc_item_title_style_default">our team</h6>
<div class="sc_item_descr sc_title_descr sc_align_left">
<p>Donec fringilla, justo quam sodales a vehicula ipsum libero eget mi Integer condimentum, nibh aliquet fringilla. Donec fringilla. Donec fringilla, justo quam sodales a vehicula ipsum libero eget mi Integer condimentum, nibh aliquet fringilla. Donec fringilla.</p>
</div>
</div>
<!-- /.sc_title -->
<div class="vc_progress_bar wpb_content_element vc_custom_1493025760097" >
<div class="vc_general vc_single_bar">
<small class="vc_label">Climate change <span class="vc_label_units">94%</span>
</small>
<span class="vc_bar " data-percentage-value="94" data-value="94" style="background-color:#a1c643;">
</span>
</div>
<div class="vc_general vc_single_bar">
<small class="vc_label">Forests <span class="vc_label_units">87%</span>
</small>
<span class="vc_bar " data-percentage-value="87" data-value="87" style="background-color:#a1c643;">
</span>
</div>
<div class="vc_general vc_single_bar">
<small class="vc_label">Toxic pollution <span class="vc_label_units">97%</span>
</small>
<span class="vc_bar " data-percentage-value="97" data-value="97" style="background-color:#a1c643;">
</span>
</div>
<div class="vc_general vc_single_bar">
<small class="vc_label">Agriculture <span class="vc_label_units">98%</span>
</small>
<span class="vc_bar " data-percentage-value="98" data-value="98" style="background-color:#a1c643;">
</span>
</div>
</div>
<a href="/how-we-work/" id="sc_button_1995577385" class="sc_button sc_button_gradient  vc_custom_1503995930984 sc_button_size_large sc_button_icon_left">
<span class="sc_button_text">
<span class="sc_button_title">more info about team</span>
</span>
<!-- /.sc_button_text -->
</a>
<!-- /.sc_button -->
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-1 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="sc_team sc_team_short">
<div class="sc_team_columns sc_item_columns trx_addons_columns_wrap columns_padding_bottom">
<div class="trx_addons_column-1_2">
<div class="sc_team_item">
<div class="post_featured sc_team_item_thumb trx_addons_hover trx_addons_hover_style_info"> <a href="http://ecoplanet.ancorathemes.com/team/jason-steele/" aria-hidden="true">
<img width="370" height="370" src="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-370x370.jpg" class="attachment-trx_addons-thumb-avatar size-trx_addons-thumb-avatar wp-post-image" alt="Jason Steele" srcset="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-370x370.jpg 370w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-150x150.jpg 150w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-120x120.jpg 120w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-240x240.jpg 240w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-300x300.jpg 300w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-100x100.jpg 100w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-1-740x740.jpg 740w" sizes="(max-width: 370px) 100vw, 370px" />
</a>
<div class="trx_addons_hover_content">
<div class="sc_team_item_socials socials_wrap trx_addons_hover_info">
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_twitter">
<span class="icon-twitter">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
<div class="trx_addons_hover_mask">
</div>
</div>
<div class="sc_team_item_info">
<div class="sc_team_item_header">
<h4 class="sc_team_item_title">
<a href="http://ecoplanet.ancorathemes.com/team/jason-steele/">Jason Steele</a>
</h4>
<div class="sc_team_item_subtitle">volunteer</div>
</div>
</div>
</div>
</div>
<div class="trx_addons_column-1_2">
<div class="sc_team_item">
<div class="post_featured sc_team_item_thumb trx_addons_hover trx_addons_hover_style_info"> <a href="http://ecoplanet.ancorathemes.com/team/sarah-johnson/" aria-hidden="true">
<img width="370" height="370" src="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-370x370.jpg" class="attachment-trx_addons-thumb-avatar size-trx_addons-thumb-avatar wp-post-image" alt="Sarah Johnson" srcset="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-370x370.jpg 370w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-150x150.jpg 150w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-120x120.jpg 120w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-240x240.jpg 240w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-300x300.jpg 300w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-100x100.jpg 100w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-2-740x740.jpg 740w" sizes="(max-width: 370px) 100vw, 370px" />
</a>
<div class="trx_addons_hover_content">
<div class="sc_team_item_socials socials_wrap trx_addons_hover_info">
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_twitter">
<span class="icon-twitter">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
<div class="trx_addons_hover_mask">
</div>
</div>
<div class="sc_team_item_info">
<div class="sc_team_item_header">
<h4 class="sc_team_item_title">
<a href="http://ecoplanet.ancorathemes.com/team/sarah-johnson/">Sarah Johnson</a>
</h4>
<div class="sc_team_item_subtitle">volunteer</div>
</div>
</div>
</div>
</div>
<div class="trx_addons_column-1_2">
<div class="sc_team_item">
<div class="post_featured sc_team_item_thumb trx_addons_hover trx_addons_hover_style_info"> <a href="http://ecoplanet.ancorathemes.com/team/peter-cotton/" aria-hidden="true">
<img width="370" height="370" src="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-370x370.jpg" class="attachment-trx_addons-thumb-avatar size-trx_addons-thumb-avatar wp-post-image" alt="Peter Cotton" srcset="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-370x370.jpg 370w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-150x150.jpg 150w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-120x120.jpg 120w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-240x240.jpg 240w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-300x300.jpg 300w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-100x100.jpg 100w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-3-740x740.jpg 740w" sizes="(max-width: 370px) 100vw, 370px" />
</a>
<div class="trx_addons_hover_content">
<div class="sc_team_item_socials socials_wrap trx_addons_hover_info">
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_twitter">
<span class="icon-twitter">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
<div class="trx_addons_hover_mask">
</div>
</div>
<div class="sc_team_item_info">
<div class="sc_team_item_header">
<h4 class="sc_team_item_title">
<a href="http://ecoplanet.ancorathemes.com/team/peter-cotton/">Peter Cotton</a>
</h4>
<div class="sc_team_item_subtitle">volunteer</div>
</div>
</div>
</div>
</div>
<div class="trx_addons_column-1_2">
<div class="sc_team_item">
<div class="post_featured sc_team_item_thumb trx_addons_hover trx_addons_hover_style_info"> <a href="http://ecoplanet.ancorathemes.com/team/elizabeth-moore/" aria-hidden="true">
<img width="370" height="370" src="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-370x370.jpg" class="attachment-trx_addons-thumb-avatar size-trx_addons-thumb-avatar wp-post-image" alt="Elizabeth Moore" srcset="http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-370x370.jpg 370w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-150x150.jpg 150w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-120x120.jpg 120w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-240x240.jpg 240w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-300x300.jpg 300w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-100x100.jpg 100w, http://ecoplanet.ancorathemes.com/wp-content/uploads/2017/03/team-4-740x740.jpg 740w" sizes="(max-width: 370px) 100vw, 370px" />
</a>
<div class="trx_addons_hover_content">
<div class="sc_team_item_socials socials_wrap trx_addons_hover_info">
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_tumblr">
<span class="icon-tumblr">
</span>
</span>
</a>
<a target="_blank" href="#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
<div class="trx_addons_hover_mask">
</div>
</div>
<div class="sc_team_item_info">
<div class="sc_team_item_header">
<h4 class="sc_team_item_title">
<a href="http://ecoplanet.ancorathemes.com/team/elizabeth-moore/">Elizabeth Moore</a>
</h4>
<div class="sc_team_item_subtitle">head of the project</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- /.sc_team -->
</div>
</div>
</div>
</div>
<div class="vc_row-full-width vc_clearfix">
</div>
<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1492687903312 vc_row-has-fill">
<div class="wpb_column vc_column_container vc_col-sm-6 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div  id="sc_action_1124331782" 
 class="scheme_dark sc_action sc_action_default">
<div class="sc_action_content sc_item_content">
<div class="sc_action_item sc_action_item_default sc_action_item_ml">
<div class="sc_action_item_icon sc_action_item_icon_type_ Array"
 >
<span class="sc_action_item_icon_type_ Array"
 >
</span>
</div>
<h6 class="sc_action_item_subtitle">
<span>take action</span>
</h6>
<h4 class="sc_action_item_title">
<span>Our Climate and Communities Can&#039;t Wait. Join the Resistance with a Gift to GreenPlanet.</span>
</h4>
<a href="/projects/" class="sc_button sc_button_gradient sc_button_size_large">take action</a>
</div>
</div>
</div>
<!-- /.sc_action -->
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
</div>
<div class="vc_row-full-width vc_clearfix">
</div>
<div class="vc_row wpb_row vc_row-fluid vc_custom_1492690519932">
<div class="wpb_column vc_column_container vc_col-sm-2 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-8 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div id="sc_services_1762105018" class="sc_services sc_services_iconed sc_services_featured_top">
<h2 class="sc_item_title sc_services_title sc_align_center sc_item_title_style_default">How We Work</h2>
<h6 class="sc_item_subtitle sc_services_subtitle sc_align_center sc_item_title_style_default">join us!</h6>
<div class="sc_services_columns sc_item_columns sc_item_columns_4 trx_addons_columns_wrap columns_padding_bottom">
<div class="trx_addons_column-1_4 ">
<div class="sc_services_item without_content with_icon sc_services_item_featured_top">
<div class="sc_services_item_header"> <a href="http://ecoplanet.ancorathemes.com/services/advocate/"
 id="sc_services_1762105018_icon-icon1"
 class="sc_services_item_icon icon-icon1"
 >
</a>
<h6 class="sc_services_item_title">
<a href="http://ecoplanet.ancorathemes.com/services/advocate/">Advocate</a>
</h6>
<div class="sc_services_item_subtitle">
<a href="http://ecoplanet.ancorathemes.com/services_group/how-we-work/" title="View all posts in How We Work">How We Work</a>
</div>
</div>
</div>
</div>
<div class="trx_addons_column-1_4 ">
<div class="sc_services_item without_content with_icon sc_services_item_featured_top">
<div class="sc_services_item_header"> <a href="http://ecoplanet.ancorathemes.com/services/innovate/"
 id="sc_services_1762105018_icon-icon2"
 class="sc_services_item_icon icon-icon2"
 >
</a>
<h6 class="sc_services_item_title">
<a href="http://ecoplanet.ancorathemes.com/services/innovate/">Innovate</a>
</h6>
<div class="sc_services_item_subtitle">
<a href="http://ecoplanet.ancorathemes.com/services_group/how-we-work/" title="View all posts in How We Work">How We Work</a>
</div>
</div>
</div>
</div>
<div class="trx_addons_column-1_4 ">
<div class="sc_services_item without_content with_icon sc_services_item_featured_top">
<div class="sc_services_item_header"> <a href="http://ecoplanet.ancorathemes.com/services/investigate/"
 id="sc_services_1762105018_icon-icon3"
 class="sc_services_item_icon icon-icon3"
 >
</a>
<h6 class="sc_services_item_title">
<a href="http://ecoplanet.ancorathemes.com/services/investigate/">Investigate</a>
</h6>
<div class="sc_services_item_subtitle">
<a href="http://ecoplanet.ancorathemes.com/services_group/how-we-work/" title="View all posts in How We Work">How We Work</a>
</div>
</div>
</div>
</div>
<div class="trx_addons_column-1_4 ">
<div class="sc_services_item without_content with_icon sc_services_item_featured_top">
<div class="sc_services_item_header"> <a href="http://ecoplanet.ancorathemes.com/services/collaborate/"
 id="sc_services_1762105018_icon-icon4"
 class="sc_services_item_icon icon-icon4"
 >
</a>
<h6 class="sc_services_item_title">
<a href="http://ecoplanet.ancorathemes.com/services/collaborate/">Collaborate</a>
</h6>
<div class="sc_services_item_subtitle">
<a href="http://ecoplanet.ancorathemes.com/services_group/how-we-work/" title="View all posts in How We Work">How We Work</a>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- /.sc_services -->
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-2 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
</div>
</div>
</div>
</div>
<div class="vc_row wpb_row vc_row-fluid">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="sc_layouts sc_layouts_default sc_layouts_186">
<div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1491492610034 vc_row-has-fill">
<div class="wpb_column vc_column_container vc_col-sm-6 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="wpb_text_column wpb_content_element " >
<div class="wpb_wrapper">
<h4 class="trx_addons_no_margin">
<span style="color: #ffffff;">
<em>Stay</em> Tuned with Our Updates</span>
</h4>
<p>
<span style="color: #ffffff; font-family: Montserrat; font-size: 0.875rem; font-weight: 500; text-transform: uppercase;">signup for newsletter</span>
</p>
</div>
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-6 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="wpb_text_column wpb_content_element " >
<div class="wpb_wrapper"> <script>(function() {
	if (!window.mc4wp) {
		window.mc4wp = {
			listeners: [],
			forms    : {
				on: function (event, callback) {
					window.mc4wp.listeners.push({
						event   : event,
						callback: callback
					});
				}
			}
		}
	}
})();</script>
<!-- Mailchimp for WordPress v4.5.3 - https://wordpress.org/plugins/mailchimp-for-wp/ -->
<form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-488" method="post" data-id="488" data-name="" >
<div class="mc4wp-form-fields">
<div> <input type="email" name="EMAIL" placeholder="Enter Your Email" required /> <input type="submit" value="submit" />
<p> <label> <input name="AGREE_TO_TERMS" type="checkbox" value="1" required="">I have read and agree to the <a href="/privacy-policy/" target="_blank">terms &amp; conditions</a> </label>
</p>
</div>
</div>
<label style="display: none !important;">Leave this field empty if you're human: <input type="text" name="_mc4wp_honeypot" value="" tabindex="-1" autocomplete="off" />
</label>
<input type="hidden" name="_mc4wp_timestamp" value="1566457950" />
<input type="hidden" name="_mc4wp_form_id" value="488" />
<input type="hidden" name="_mc4wp_form_element_id" value="mc4wp-form-1" />
<div class="mc4wp-response">
</div>
</form>
<!-- / Mailchimp for WordPress Plugin -->
</div>
</div>
</div>
</div>
</div>
</div>
<div class="vc_row-full-width vc_clearfix">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- .entry-content -->
</article>
</div>
<!-- </.content> -->
</div>
<!-- </.content_wrap> -->
</div>
<!-- </.page_content_wrap> -->
<?php include "footer.php"
?>