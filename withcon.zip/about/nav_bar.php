<div class="wpb_wrapper">
<div class="sc_layouts_item">
<a href="https://sarvdharm.000webhostapp.com/" id="sc_layouts_logo_2110503488" class="sc_layouts_logo sc_layouts_logo_default">
<img class="logo_image" src="../wp-content/uploads/03/logo_footer.png" alt="" width="229" height="58">
</a>
<!-- /.sc_layouts_logo -->
</div>
</div>
</div>
</div>
<div class="wpb_column vc_column_container vc_col-sm-9 sc_layouts_column sc_layouts_column_align_right sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<div class="sc_layouts_item">
<nav id="sc_layouts_menu_1162794979" class="sc_layouts_menu sc_layouts_menu_default menu_hover_fade hide_on_mobile">
<ul id="menu_main" class="sc_layouts_menu_nav menu_main_nav">
<li id="menu-item-151" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-151">
<a href="#">
<span>Home</span>
</a>
<ul class="sub-menu">
<li id="menu-item-336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-336">
<a href="index.php">
<span>Home </span>
</a>
</li>
</ul>
</li>
<li id="menu-item-152" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-152">
<a href="#">
<span>Gallery</span>
</a>
</li>
<li id="menu-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338">
<a href="#">
<span>About</span>
</a>
<ul class="sub-menu">
<li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339">
<a href="https://sarvdharm.000webhostapp.com/our-mission/">
<span>Our Mission</span>
</a>
</li>
<li id="menu-item-340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-340">
<a href="https://sarvdharm.000webhostapp.com/how-we-work/">
<span>How We Work</span>
</a>
</li>
</ul>
</li>

<li id="menu-item-163" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-163">
<a href="#">
<span>Blog</span>
</a>
</li>
<li id="menu-item-188" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-176 current_page_item menu-item-188">
<a href="https://sarvdharm.000webhostapp.com/contacts/" aria-current="page">
<span>Contacts</span>
</a>
</li>
</ul>
</nav>
<!-- /.sc_layouts_menu -->
<div class="sc_layouts_iconed_text sc_layouts_menu_mobile_button"> <a class="sc_layouts_item_link sc_layouts_iconed_text_link" href="#"> <span class="sc_layouts_item_icon sc_layouts_iconed_text_icon trx_addons_icon-menu">
</span> </a>
</div>
</div>
<div class="sc_layouts_item sc_layouts_hide_on_mobile sc_layouts_hide_on_tablet">
<div id="sc_layouts_search_108795814" class="sc_layouts_search hide_on_tablet hide_on_mobile">
<div class="search_wrap search_style_fullscreen search_ajax layouts_search">
<div class="search_form_wrap">
<form role="search" method="get" class="search_form" action="https://sarvdharm.000webhostapp.com/"> <input type="text" class="search_field" placeholder="Search" value="" name="s"> <button type="submit" class="search_submit trx_addons_icon-search">
</button> <a class="search_close trx_addons_icon-delete">
</a>
</form>
</div>
<div class="search_results widget_area">
<a href="#" class="search_results_close trx_addons_icon-cancel">
</a>
<div class="search_results_content">
</div>
</div>
</div>
</div>
<!-- /.sc_layouts_search -->
</div>
<div class="sc_layouts_item sc_layouts_hide_on_tablet">
<a href="/projects/" id="sc_button_92711954" class="hide_on_tablet sc_button sc_button_gradient  vc_custom_1494237196387 sc_button_size_normal sc_button_icon_left">
<span class="sc_button_text">
<span class="sc_button_title">Get Involved</span>
</span>
<!-- /.sc_button_text -->
</a>
<!-- /.sc_button -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>