 <!-- /.sc_layouts_title -->
 </div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- /.sc_content -->
</div>
</div>
</div>
</div>
</header>
<div class="menu_mobile_overlay">
</div>
<div class="menu_mobile menu_mobile_fullscreen scheme_dark">
<div class="menu_mobile_inner"> <a class="menu_mobile_close icon-cancel">
</a>
<nav class="menu_mobile_nav_area">
<ul id="menu_mobile" class=" menu_mobile_nav">
<li id="menu_mobile-item-151" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-151">
<a href="../index.php">
<span>Home</span>
</a>
<ul class="sub-menu">
<li id="menu_mobile-item-336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-336">
<a href="../index.php">
<span>Home </span>
</a>
</li>
</ul>
</li>
<li id="menu_mobile-item-152" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-152">
<a href="#">
<span>Gallery</span>
</a>
<ul class="sub-menu">
<!-- <li id="menu_mobile-item-897" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-privacy-policy menu-item-897">
<a href="#privacy-policy/">
<span>Privacy Policy</span>
</a>
</li> -->
<!-- <li id="menu_mobile-item-258" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-258">
<a href="#shop/">
<span>Store</span>
</a>
</li> -->
<!-- <li id="menu_mobile-item-159" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-159">
<a href="#">
<span>Gallery</span>
</a>
</li> -->
</ul>
</li>
<li id="menu_mobile-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338">
<a href="#">
<span>About</span>
    </a>
<ul class="sub-menu">
<li id="menu_mobile-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339">
<a href="#our-mission/">
<span>Our Mission</span>
</a>
</li>
<li id="menu_mobile-item-340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-340">
<a href="#how-we-work/">
<span>How We Work</span>
</a>
</li>
</ul>
</li>
<li id="menu_mobile-item-163" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-163">
<a href="#">
<span>Blog</span>
</a>

</nav>
<div class="search_wrap search_style_normal search_mobile">
<div class="search_form_wrap">
<form role="search" method="get" class="search_form" action="#"> <input type="text" class="search_field" placeholder="Search" value="" name="s"> <button type="submit" class="search_submit trx_addons_icon-search">
</button>
</form>
</div>
</div>
<div class="socials_mobile">
<a target="_blank" href="https://www.facebook.com/#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="https://twitter.com/Brahmrishi" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_twitter">
<span class="icon-twitter">
</span>
</span>
</a>
<a target="_blank" href="https://www.instagram.com/#" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
</div>
<div class="page_content_wrap scheme_default">
<div class="content_wrap">
<div class="content">
<article id="post-84" class="clearfix post_item_single post_type_post post_format_ itemscope post-84 post type-post status-publish format-standard has-post-thumbnail hentry category-flora-fauna tag-energy tag-saving"             itemscope itemtype="http://schema.org/BlogPosting">
    <div class="post_featured"> <img width="1170" height="658" src="wp-content/uploads/03/post-4-1170x658.jpg" class="attachment-green_planet-thumb-huge size-green_planet-thumb-huge wp-post-image" alt="Northern Waters Break the Ice and Melt It" itemprop="url" srcset="wp-content/uploads/03/post-4-1170x658.jpg 1170w, wp-content/uploads/03/post-4-760x428.jpg 760w, wp-content/uploads/03/post-4-1520x856.jpg 1520w, wp-content/uploads/03/post-4-370x208.jpg 370w, wp-content/uploads/03/post-4-740x416.jpg 740w, wp-content/uploads/03/post-4-480x270.jpg 480w, wp-content/uploads/03/post-4-270x152.jpg 270w, wp-content/uploads/03/post-4-540x304.jpg 540w" sizes="(max-width: 1170px) 100vw, 1170px" />
</div>
 