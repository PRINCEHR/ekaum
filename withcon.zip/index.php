<?php include 'header.php'
?>
					
					<body class="home page-template-default page page-id-331 frontpage woocommerce-no-js body_tag scheme_default blog_mode_home body_style_wide  is_stream blog_style_excerpt sidebar_hide expand_content remove_margins header_style_header-custom-655 header_position_default menu_style_top no_layout wpb-js-composer js-comp-ver-6.0.1 vc_responsive">
					
<!-- <div id="google_translate_element">
</div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit">
</script> -->

					<div class="body_wrap">
					<div class="page_wrap">
					<header class="top_panel top_panel_custom top_panel_custom_655 top_panel_custom_header-1-without-title without_bg_image scheme_default">
					
					<div class="vc_row wpb_row vc_row-fluid vc_row-o-content-middle vc_row-flex sc_layouts_row sc_layouts_row_type_normal sc_layouts_row_fixed">
					
					<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
					
					<div class="vc_column-inner">
					<div class="wpb_wrapper">
					<div id="sc_content_681901766"
 class="sc_content sc_content_default sc_float_center sc_content_width_1_1">
 <div class="sc_content_container">
 
 <div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-middle vc_row-flex">
 <div class="wpb_column vc_column_container vc_col-sm-3 sc_layouts_column sc_layouts_column_align_left sc_layouts_column_icons_position_left">
 <div class="vc_column-inner">
 <div class="wpb_wrapper">
 <div class="sc_layouts_item">
<a href="#" id="sc_layouts_logo_1339058846" class="sc_layouts_logo sc_layouts_logo_default">
 
 <img class="logo_image" src="wp-content/uploads/03/logo_footer.png" alt="" width="229" height="58">
</a>
<!-- /.sc_layouts_logo -->
</div>
</div>
</div>
</div>
 
 <div class="wpb_column vc_column_container vc_col-sm-9 sc_layouts_column sc_layouts_column_align_right sc_layouts_column_icons_position_left">
 <div class="vc_column-inner">
 <div class="wpb_wrapper">
 <div class="sc_layouts_item">
 <nav id="sc_layouts_menu_1761868716" class="sc_layouts_menu sc_layouts_menu_default menu_hover_fade hide_on_mobile">
 <ul id="menu_main" class="sc_layouts_menu_nav menu_main_nav">
 <li id="menu-item-151" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-151">
<a href="#">
<span>Home</span>
</a>
<ul class="sub-menu">
<li id="menu-item-336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-331 current_page_item menu-item-336">
	 
	 <a href="https://bslndapps.000webhostapp.com/" aria-current="page">
<span>Home </span>
</a>
</li>
<li id="menu-item-337" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-337">
	 
	 </li>
</ul>
</li>
	 
	 <li id="menu-item-152" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-152">
<a href="#">
<span>Gallery</span>
</a>
<!-- <ul class="sub-menu"> -->

<!-- <li id="menu-item-159" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-159">
<a href="#">
<span>Gallery</span>
</a>
</li> -->
<!-- </ul> -->
</li>
<li id="menu-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338">
<a href="#">
<span>About</span>
</a>
<ul class="sub-menu">
<li id="menu-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339">
<a href="#our-mission/">
<span>Our Mission</span>
</a>
</li>
<li id="menu-item-340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-340">
<a href="#how-we-work/">
<span>How We Work</span>
</a>
</li>
</ul>
</li>
<li id="menu-item-163" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-163">
<a href="blog/blog_christ.php">
<span>Blog</span>
</a>
</li>
<li id="menu-item-188" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-188">
<a href="contact.php">
<span>Contacts</span>
</a>
</li>
</ul>
</nav>
<!-- /.sc_layouts_menu -->
<div class="sc_layouts_iconed_text sc_layouts_menu_mobile_button"> <a class="sc_layouts_item_link sc_layouts_iconed_text_link" href="#"> <span class="sc_layouts_item_icon sc_layouts_iconed_text_icon trx_addons_icon-menu">
</span> </a>
</div>
</div>
<div class="sc_layouts_item sc_layouts_hide_on_mobile sc_layouts_hide_on_tablet">
<div id="sc_layouts_search_2087780635" class="sc_layouts_search hide_on_tablet hide_on_mobile">
<div class="search_wrap search_style_fullscreen search_ajax layouts_search">
<div class="search_form_wrap">
<form role="search" method="get" class="search_form" action="#"> <input type="text" class="search_field" placeholder="Search" value="" name="s"> <button type="submit" class="search_submit trx_addons_icon-search">
</button> <a class="search_close trx_addons_icon-delete">
</a>
</form>
</div>
<div class="search_results widget_area">
<a href="#" class="search_results_close trx_addons_icon-cancel">
</a>
<div class="search_results_content">
</div>
</div>
</div>
</div>
<!-- /.sc_layouts_search -->
</div>
<div class="sc_layouts_item sc_layouts_hide_on_tablet">
<a href="#" id="sc_button_803236063" class="hide_on_tablet sc_button sc_button_gradient  vc_custom_1494237109280 sc_button_size_normal sc_button_icon_left">
<span class="sc_button_text">
<span class="sc_button_title">Get Involved</span>
</span>
<!-- /.sc_button_text -->
</a>
<!-- /.sc_button -->
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- /.sc_content -->
</div>
</div>
</div>
</div>
</header>
<div class="menu_mobile_overlay">
</div>
<div class="menu_mobile menu_mobile_fullscreen scheme_dark">
<div class="menu_mobile_inner"> <a class="menu_mobile_close icon-cancel">
</a>
<nav class="menu_mobile_nav_area">
<ul id="menu_mobile" class=" menu_mobile_nav">
<li id="menu_mobile-item-151" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-ancestor current-menu-parent menu-item-has-children menu-item-151">
<a href="#">
<span>Home</span>
</a>
<ul class="sub-menu">
<li id="menu_mobile-item-336" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-331 current_page_item menu-item-336">
<a href="#" aria-current="page">
<span>Home </span>
</a>
</li>
</ul>
</li>
<li id="menu_mobile-item-152" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-152">
<a href="#">
<span>Features</span>
</a>
<li id="menu_mobile-item-159" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-159">
<a href="#">
<span>Gallery</span>
</a>
</li>
</ul>
</li>
<li id="menu_mobile-item-338" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-338">
<a href="#">
<span>About</span>
</a>
<ul class="sub-menu">
<li id="menu_mobile-item-339" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-339">
<a href="#our-mission/">
<span>Our Mission</span>
</a>
</li>
<li id="menu_mobile-item-340" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-340">
<a href="#how-we-work/">
<span>How We Work</span>
</a>
</li>
</ul>
</li>
<li id="menu_mobile-item-163" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-163">
<a href="#">
<span>Blog</span>
</a>
</li>
<li id="menu_mobile-item-188" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-188">
<a href="#contacts/">
<span>Contacts</span>
</a>
</li>
</ul>
</nav>
<div class="search_wrap search_style_normal search_mobile">
<div class="search_form_wrap">
<form role="search" method="get" class="search_form" action="#"> <input type="text" class="search_field" placeholder="Search" value="" name="s"> <button type="submit" class="search_submit trx_addons_icon-search">
</button>
</form>
</div>
</div>
<div class="socials_mobile">
<a target="_blank" href="https://www.facebook.com/AncoraThemes/" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_facebook">
<span class="icon-facebook">
</span>
</span>
</a>
<a target="_blank" href="https://twitter.com/ancora_themes" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_twitter">
<span class="icon-twitter">
</span>
</span>
</a>
<a target="_blank" href="https://www.instagram.com/ancora_themes/" class="social_item social_item_style_icons social_item_type_icons">
<span class="social_icon social_instagramm">
<span class="icon-instagramm">
</span>
</span>
</a>
</div>
</div>
</div>
<div class="page_content_wrap scheme_default">
<div class="content_wrap">
<div class="content">
<article id="post-331" class="post_item_single post_type_page post-331 page type-page status-publish hentry">
<div class="post_content entry-content">
<div data-vc-full-width="true" data-vc-full-width-init="false" data-vc-stretch-content="true" class="vc_row wpb_row vc_row-fluid vc_row-no-padding">
<div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left">
<div class="vc_column-inner">
<div class="wpb_wrapper">
<link href="http://fonts.googleapis.com/css?family=Playfair+Display:700" rel="stylesheet" property="stylesheet" type="text/css" media="all">
<div id="rev_slider_1_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery" style="margin:0px auto;background:transparent;padding:0px;margin-top:0px;margin-bottom:0px;"> <!-- START REVOLUTION SLIDER 5.4.8.3 fullwidth mode -->
<div id="rev_slider_1_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.8.3">
<ul> <!-- SLIDE  -->
<li data-index="rs-1" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="wp-content/uploads/04/home1_slide1-280x140.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Make the Society Healthier And Happier" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description=""> <!-- MAIN IMAGE --> <img src="wp-content/uploads/04/home1_slide1.jpg"  alt="" title="home1_slide1"  width="1920" height="810" data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="110" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina> <!-- LAYERS --> <!-- LAYER NR. 1 -->
<div class="tp-caption   tp-resizeme" 
 id="slide-1-layer-1" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="5" 
 data-width="['none','none','none','none']"
 data-height="['none','none','none','none']" 
 data-type="image" 
 data-responsive_offset="on"  data-frames='[{"delay":2000,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 5;">
 <img src="wp-content/uploads/03/patterns.png" alt="" data-ww="1920px" data-hh="175px" width="1920" height="175" data-no-retina>
</div> <!-- LAYER NR. 2 -->
<div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme" 
 id="slide-1-layer-2" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="-4" 
 data-width="['1920']"
 data-height="['10']" 
 data-type="shape" 
 data-responsive_offset="on"  data-frames='[{"delay":2140,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 6;background-color:rgb(255,255,255);">
</div> <!-- LAYER NR. 3 -->
<div class="tp-caption subtitle-slide   tp-resizeme" 
 id="slide-1-layer-3" 
 data-x="3" 
 data-y="218" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":10,"speed":1000,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 7; white-space: nowrap; letter-spacing: 0px;">Beej Mantra`s can</div> <!-- LAYER NR. 4 -->
<div class="tp-caption title-slide   tp-resizeme" 
 id="slide-1-layer-5" 
 data-x="2"  data-y="261" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":1200,"speed":1500,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 8; white-space: nowrap; letter-spacing: 0px;text-transform:uppercase;">
<span style="font-style: italic; text-transform: capitalize">Make</span> the Soceity<br>Happier</div></li> <!-- SLIDE  --><li data-index="rs-5" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="wp-content/uploads/04/home1_slide2-280x140.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Save From Uncurable Disease" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description=""> <!-- MAIN IMAGE --> <img src="wp-content/uploads/04/home1_slide2.jpg"  alt="" title="home1_slide2"  width="1920" height="810" data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="110" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina> <!-- LAYERS --> <!-- LAYER NR. 5 --><div class="tp-caption   tp-resizeme" 
 id="slide-5-layer-1" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="5" 
 data-width="['none','none','none','none']"
 data-height="['none','none','none','none']" 
 data-type="image" 
 data-responsive_offset="on"  data-frames='[{"delay":2000,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 5;"><img src="wp-content/uploads/03/patterns.png" alt="" data-ww="1920px" data-hh="175px" width="1920" height="175" data-no-retina></div> <!-- LAYER NR. 6 --><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme" 
 id="slide-5-layer-2" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="-4" 
 data-width="['1920']"
 data-height="['10']" 
 data-type="shape" 
 data-responsive_offset="on"  data-frames='[{"delay":2140,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 6;background-color:rgb(255,255,255);"></div> <!-- LAYER NR. 7 --><div class="tp-caption subtitle-slide   tp-resizeme" 
 id="slide-5-layer-3" 
 data-x="2" 
 data-y="218" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":10,"speed":1000,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 7; white-space: nowrap; letter-spacing: 0px;">Beej Mantra`s  can</div> <!-- LAYER NR. 8 --><div class="tp-caption title-slide   tp-resizeme" 
 id="slide-5-layer-5" 
 data-x="2" 
 data-y="261" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":1200,"speed":1500,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 8; white-space: nowrap; letter-spacing: 0px;text-transform:uppercase;"><span style="font-style: italic; text-transform: capitalize">Save</span> People<br>From Uncurable Disease</div></li> <!-- SLIDE  --><li data-index="rs-6" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="wp-content/uploads/04/home1_slide3-280x140.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Art Of Living Good Life" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description=""> <!-- MAIN IMAGE --> <img src="wp-content/uploads/04/home1_slide3.jpg"  alt="" title="home1_slide3"  width="1920" height="810" data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="100" data-scaleend="110" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina> <!-- LAYERS --> <!-- LAYER NR. 9 --><div class="tp-caption   tp-resizeme" 
 id="slide-6-layer-1" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="5" 
 data-width="['none','none','none','none']"
 data-height="['none','none','none','none']" 
 data-type="image" 
 data-responsive_offset="on"  data-frames='[{"delay":2000,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 5;"><img src="wp-content/uploads/03/patterns.png" alt="" data-ww="1920px" data-hh="175px" width="1920" height="175" data-no-retina></div> <!-- LAYER NR. 10 --><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme" 
 id="slide-6-layer-2" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="-4" 
 data-width="['1920']"
 data-height="['10']" 
 data-type="shape" 
 data-responsive_offset="on"  data-frames='[{"delay":2140,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 6;background-color:rgb(255,255,255);"></div> <!-- LAYER NR. 11 --><div class="tp-caption subtitle-slide   tp-resizeme" 
 id="slide-6-layer-3" 
 data-x="2" 
 data-y="218" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":10,"speed":1000,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 7; white-space: nowrap; letter-spacing: 0px;">Beej Mantra`s provides</div> <!-- LAYER NR. 12 --><div class="tp-caption title-slide   tp-resizeme" 
 id="slide-6-layer-5" 
 data-x="2" 
 data-y="261" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":1200,"speed":1500,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 8; white-space: nowrap; letter-spacing: 0px;text-transform:uppercase;"><span style="font-style: italic; text-transform: capitalize">An</span> Art of <br>Living <br>Good Life </div></li> <!-- SLIDE  --><li data-index="rs-7" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="wp-content/uploads/04/home1_slide4-280x140.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Lead A Prosperous Life" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description=""> <!-- MAIN IMAGE --> <img src="wp-content/uploads/04/home1_slide4.jpg"  alt="" title="home1_slide4"  width="1920" height="810" data-bgposition="center center" data-kenburns="on" data-duration="10000" data-ease="Linear.easeNone" data-scalestart="110" data-scaleend="100" data-rotatestart="0" data-rotateend="0" data-blurstart="0" data-blurend="0" data-offsetstart="0 0" data-offsetend="0 0" class="rev-slidebg" data-no-retina> <!-- LAYERS --> <!-- LAYER NR. 13 --><div class="tp-caption   tp-resizeme" 
 id="slide-7-layer-1" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="5" 
 data-width="['none','none','none','none']"
 data-height="['none','none','none','none']" 
 data-type="image" 
 data-responsive_offset="on"  data-frames='[{"delay":2000,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 5;"><img src="wp-content/uploads/03/patterns.png" alt="" data-ww="1920px" data-hh="175px" width="1920" height="175" data-no-retina></div> <!-- LAYER NR. 14 --><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme" 
 id="slide-7-layer-2" 
 data-x="center" data-hoffset="" 
 data-y="bottom" data-voffset="-4" 
 data-width="['1920']"
 data-height="['10']" 
 data-type="shape" 
 data-responsive_offset="on"  data-frames='[{"delay":2140,"speed":1200,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","mask":"x:0px;y:[100%];s:inherit;e:inherit;","to":"o:1;","ease":"Power2.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 6;background-color:rgb(255,255,255);"></div> <!-- LAYER NR. 15 --><div class="tp-caption subtitle-slide   tp-resizeme" 
 id="slide-7-layer-3" 
 data-x="2" 
 data-y="218" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":10,"speed":1000,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 7; white-space: nowrap; letter-spacing: 0px;">Beej Mantra`s </div> <!-- LAYER NR. 16 --><div class="tp-caption title-slide   tp-resizeme" 
 id="slide-7-layer-5" 
 data-x="2" 
 data-y="261" 
 data-width="['auto']"
 data-height="['auto']" 
 data-type="text" 
 data-responsive_offset="on"  data-frames='[{"delay":1200,"speed":1500,"frame":"0","from":"x:left;","to":"o:1;","ease":"Power3.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
 data-textAlign="['inherit','inherit','inherit','inherit']"
 data-paddingtop="[0,0,0,0]"
 data-paddingright="[0,0,0,0]"
 data-paddingbottom="[0,0,0,0]"
 data-paddingleft="[0,0,0,0]"  style="z-index: 8; white-space: nowrap; letter-spacing: 0px;text-transform:uppercase;"><span style="font-style: italic; text-transform: capitalize">Lead </span> A A Prosperous <br> Life</div></li></ul> <script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss="";
						if(htmlDiv) {
							htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
						}else{
							var htmlDiv = document.createElement("div");
							htmlDiv.innerHTML = "";
							document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
						}</script> <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div></div> <script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss=".tp-caption.subtitle-slide,.subtitle-slide{color:#a1c643;font-size:25px;line-height:28px;font-weight:700;font-style:normal;font-family:Playfair Display;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-width:0px 0px 0px 0px;border-radius:0px 0px 0px 0px}.tp-caption.title-slide,.title-slide{color:#ffffff;font-size:90px;line-height:90px;font-weight:700;font-style:normal;font-family:Playfair Display;text-decoration:none;background-color:transparent;border-color:transparent;border-style:none;border-width:0px 0px 0px 0px;border-radius:0px 0px 0px 0px}";
				if(htmlDiv) {
					htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
				}else{
					var htmlDiv = document.createElement("div");
					htmlDiv.innerHTML = "";
					document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
				}</script> <script type="text/javascript">if (setREVStartSize!==undefined) setREVStartSize(
	{c: '#rev_slider_1_1', gridwidth: [1170], gridheight: [810], sliderLayout: 'fullwidth'});
			
var revapi1,
	tpj;	
(function() {			
	if (!/loaded|interactive|complete/.test(document.readyState)) document.addEventListener("DOMContentLoaded",onLoad); else onLoad();	
	function onLoad() {				
		if (tpj===undefined) { tpj = jQuery; if("off" == "on") tpj.noConflict();}
	if(tpj("#rev_slider_1_1").revolution == undefined){
		revslider_showDoubleJqueryError("#rev_slider_1_1");
	}else{
		revapi1 = tpj("#rev_slider_1_1").show().revolution({
			sliderType:"standard",
			jsFileLocation:"//ecoplanet.ancorathemes.com/wp-content/plugins/revslider/public/assets/js/",
			sliderLayout:"fullwidth",
			dottedOverlay:"none",
			delay:9000,
			navigation: {
				keyboardNavigation:"off",
				keyboard_direction: "horizontal",
				mouseScrollNavigation:"off",
 							mouseScrollReverse:"default",
				onHoverStop:"off",
				thumbnails: {
					style:"featured-preview",
					enable:true,
					width:269,
					height:132,
					min_width:269,
					wrapper_padding:5,
					wrapper_color:"transparent",
					tmp:'<span class="tp-thumb-image"></span><span class="tp-thumb-title">{{title}}</span><span class="tp-thumb-border"></span>',
					visibleAmount:4,
					hide_onmobile:false,
					hide_onleave:false,
					direction:"horizontal",
					span:false,
					position:"inner",
					space:30,
					h_align:"center",
					v_align:"bottom",
					h_offset:0,
					v_offset:156
				}
			},
			visibilityLevels:[1240,1024,778,480],
			gridwidth:1170,
			gridheight:810,
			lazyType:"none",
			shadow:0,
			spinner:"spinner0",
			stopLoop:"off",
			stopAfterLoops:-1,
			stopAtSlide:-1,
			shuffle:"off",
			autoHeight:"off",
			disableProgressBar:"on",
			hideThumbsOnMobile:"off",
			hideSliderAtLimit:0,
			hideCaptionAtLimit:0,
			hideAllCaptionAtLilmit:0,
			debugMode:false,
			fallbacks: {
				simplifyAll:"off",
				nextSlideOnWindowFocus:"off",
				disableFocusListener:false,
			}
		});
	}; /* END OF revapi call */
	
 }; /* END OF ON LOAD FUNCTION */
}()); /* END OF WRAPPING FUNCTION */</script> <script>var htmlDivCss = unescape("%23rev_slider_1_1%20.featured-preview%20.tp-thumb%20%7B%0A%20%20opacity%3A1%3B%0A%20%20-webkit-perspective%3A%20600px%3B%0A%20%20perspective%3A%20600px%3B%0A%7D%0A%23rev_slider_1_1%20.featured-preview%20.tp-thumb%20.tp-thumb-title%20%7B%0A%20%20%20%20font-size%3A18px%3B%0A%20%20%20%20font-family%3A%20Playfair%20Display%3B%0A%20%20%20%20position%3Aabsolute%3B%0A%20%20%20%20margin-top%3A0px%3B%0A%20%20%20%20color%3Argba%28255%2C%20255%2C%20255%2C%201%29%3B%0A%20%20%20%20display%3Ablock%3B%0A%20%20%20%20z-index%3A1000%3B%0A%20%20%20%20font-weight%3A%20700%3B%0A%20%20%20%20background-color%3Argba%280%2C%200%2C%200%2C%200.4%29%3B%0A%20%20%20%20padding%3A5px%2010px%3B%20%0A%20%20%20%20bottom%3A0px%3B%0A%20%20%20%20left%3A0px%3B%0A%20%20%20%20top%3A%200%3B%0A%20%20%20%20width%3A100%25%3B%0A%20%20-webkit-box-sizing%3Aborder-box%3B%0A%20%20%20%20%20%20%20%20%20%20box-sizing%3Aborder-box%3B%0A%20%20%20%20display%3A%20-webkit-box%3B%0A%20%20%20%20display%3A%20-webkit-flex%3B%0A%20%20%20%20display%3A%20-ms-flexbox%3B%0A%20%20%20%20display%3A%20flex%3B%0A%20%20%20%20-webkit-box-align%3A%20center%3B%0A%20%20%20%20-webkit-align-items%3A%20center%3B%0A%20%20%20%20%20%20%20%20-ms-flex-align%3A%20center%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20align-items%3A%20center%3B%0A%20%20%20%20-webkit-box-pack%3A%20center%3B%0A%20%20%20%20-webkit-justify-content%3A%20center%3B%0A%20%20%20%20%20%20%20%20-ms-flex-pack%3A%20center%3B%0A%20%20%20%20%20%20%20%20%20%20%20%20justify-content%3A%20center%3B%0A%20%20%20%20text-align%3Acenter%3B%0A%20%20%20%20overflow%3Ahidden%3B%0A%20%20%20%20transition%3Aall%200.3s%3B%0A%20%20%20%20-webkit-transition%3Aall%200.3s%3B%0A%20%20%20%20%20-ms-transform%3Arotatex%280deg%29%3B%0A%20%20%20%20%20%20%20%20%20transform%3Arotatex%280deg%29%3B%0A%20%20%20%20-webkit-transform%3Arotatex%280deg%29%3B%0A%20%20%20%20opacity%3A1%3B%0A%20%20%20%20%20%20%20%0A%20%7D%0A%23rev_slider_1_1%20.featured-preview%20.tp-thumb%3Ahover%20.tp-thumb-title%2C%0A%23rev_slider_1_1%20.featured-preview%20.tp-thumb.selected%20.tp-thumb-title%7B%0A%20%20%20%20-ms-transform%3A%20translatez%280.001px%29%3B%0A%20%20%20%20%20%20%20%20transform%3A%20translatez%280.001px%29%3B%0A%20%20%20%20-ms-transform-origin%3A50%25%20100%25%3B%0A%20%20%20%20%20%20%20%20transform-origin%3A50%25%20100%25%3B%0A%20%20%20%20-webkit-transform%3A%20translatez%280.001px%29%3B%0A%20%20%20%20-webkit-transform-origin%3A50%25%20100%25%3B%0A%20%20%20%20opacity%3A0%3B%0A%20%20%20%20%0A%7D%0A%0A%23rev_slider_1_1%20.featured-preview%20.tp-thumb.selected%20.tp-thumb-border%7B%0A%20%20%20%20position%3Aabsolute%3B%0A%20%20%20%20display%3Ablock%3B%20%0A%20%20%20%20bottom%3A0px%3B%0A%20%20%20%20left%3A0px%3B%0A%20%20%20%20top%3A%200%3B%0A%20%20%20%20right%3A%200px%3B%0A%20%20%20%20%20border%3A%205px%20solid%20%23a1c643%3B%0A%7D%0A");
					var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
					if(htmlDiv) {
						htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
					}
					else{
						var htmlDiv = document.createElement('div');
						htmlDiv.innerHTML = '';
						document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
					}</script> </div><!-- END REVOLUTION SLIDER --></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div>
				
 
 <div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left"><div class="vc_column-inner"><div class="wpb_wrapper"></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1493892421229 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left"><div class="vc_column-inner"><div class="wpb_wrapper"><div class="sc_blogger sc_blogger_default"><h2 class="sc_item_title sc_blogger_title sc_align_center sc_item_title_style_default">recent articles</h2><h6 class="sc_item_subtitle sc_blogger_subtitle sc_align_center sc_item_title_style_default">blog feed</h6><div class="sc_blogger_slider sc_item_slider	slider_swiper_outer slider_outer_nocontrols slider_outer_pagination slider_outer_pagination_bullets slider_outer_pagination_pos_bottom slider_outer_multi"><div class="swiper-slider-container slider_swiper slider_noresize slider_nocontrols slider_pagination slider_pagination_bullets slider_pagination_pos_bottom slider_multi" data-slides-per-view="3" data-slides-space="30" data-slides-min-width="300" data-pagination="bullets"><div class="slides swiper-wrapper sc_item_columns_3"><div class="swiper-slide"><div id="post-82"	class="sc_blogger_item post_format_standard post-82 post type-post status-publish format-standard has-post-thumbnail hentry category-flora-fauna tag-pollution tag-world"><div class="post_featured with_thumb hover_icon sc_blogger_item_featured"><img width="660" height="565" src="wp-content/uploads/03/post-3-660x565.jpg" class="attachment-green_planet-thumb-bigsquare size-green_planet-thumb-bigsquare wp-post-image" alt="" srcset="wp-content/uploads/03/post-3-660x565.jpg 660w, wp-content/uploads/03/post-3-1320x1130.jpg 1320w" sizes="(max-width: 660px) 100vw, 660px" />
 <div class="mask"></div><div class="icons"><a href="climate-change-solutions-are-within-our-reach/" aria-hidden="true" class="icon-resize-full-alt"></a></div></div><div class="sc_blogger_item_content entry-content"><div class="sc_blogger_item_header entry-header"><div class="post_meta clearfix"> <span class="post_meta_item post_date"><a href="climate-change-solutions-are-within-our-reach/">Aug 12, 2019</a></span></div><!-- .post_meta --><h5 class="sc_blogger_item_title entry-title"><a href="blog/blog_christ.php" rel="bookmark">मृत्यु के बाद क्या होता है<br> Christianity</a></h5></div>
 
 <!-- .entry-header --></div><!-- .entry-content --></div><!-- .sc_blogger_item --></div><div class="swiper-slide"><div id="post-84"	class="sc_blogger_item post_format_standard post-84 post type-post status-publish format-standard has-post-thumbnail hentry category-flora-fauna tag-energy tag-saving">
<div class="post_featured with_thumb hover_icon sc_blogger_item_featured">
<img width="660" height="565" src="wp-content/uploads/03/post-4-660x565.jpg" class="attachment-green_planet-thumb-bigsquare size-green_planet-thumb-bigsquare wp-post-image" alt="" srcset="wp-content/uploads/03/post-4-660x565.jpg 660w, wp-content/uploads/03/post-4-1320x1130.jpg 1320w" sizes="(max-width: 660px) 100vw, 660px" />
<div class="mask">
</div>
<div class="icons">
<a href=" northern-waters-break-the-ice-and-melt-it/" aria-hidden="true" class="icon-resize-full-alt">
</a>
</div>
</div>
<div class="sc_blogger_item_content entry-content">
<div class="sc_blogger_item_header entry-header">
<div class="post_meta clearfix"> <span class="post_meta_item post_date">
<a href=" northern-waters-break-the-ice-and-melt-it/">Aug 17, 2019</a>
</span>
</div>
 <!-- .post_meta -->
<h5 class="sc_blogger_item_title entry-title">
<a href="blog/blog_islam.php" rel="bookmark">मृत्यु के बाद क्या होता है<br> Islam</a>
</h5>
</div>
 
 <!-- .entry-header -->
</div>
<!-- .entry-content -->
</div>
<!-- .sc_blogger_item -->
</div>
<div class="swiper-slide">
<div id="post-103"	class="sc_blogger_item post_format_standard post-103 post type-post status-publish format-standard has-post-thumbnail hentry category-flora-fauna tag-energy tag-saving">
<div class="post_featured with_thumb hover_icon sc_blogger_item_featured">
<img width="660" height="565" src="wp-content/uploads/03/post-7-660x565.jpg" class="attachment-green_planet-thumb-bigsquare size-green_planet-thumb-bigsquare wp-post-image" alt="" srcset="wp-content/uploads/03/post-7-660x565.jpg 660w, wp-content/uploads/03/post-7-1320x1130.jpg 1320w" sizes="(max-width: 660px) 100vw, 660px" />
<div class="mask">
</div>
<div class="icons">
<a href="getting-energy-from-resources-around-us/" aria-hidden="true" class="icon-resize-full-alt">
</a>
</div>
</div>
 <div class="sc_blogger_item_content entry-content">
<div class="sc_blogger_item_header entry-header">
<div class="post_meta clearfix"> <span class="post_meta_item post_date">
<a href="getting-energy-from-resources-around-us/">Aug 18, 2019</a>
</span>
</div>
<!-- .post_meta -->
<h5 class="sc_blogger_item_title entry-title">
<a href="getting-energy-from-resources-around-us/" rel="bookmark">मृत्यु के बाद क्या होता है<br> Budhism</a>
</h5>
</div>
<!-- .entry-header -->
</div>
<!-- .entry-content -->
</div>
<!-- .sc_blogger_item -->
</div>
<div class="swiper-slide">
<div id="post-106"	class="sc_blogger_item post_format_standard post-106 post type-post status-publish format-standard has-post-thumbnail hentry category-flora-fauna tag-animals tag-issue">
<div class="post_featured with_thumb hover_icon sc_blogger_item_featured">
<img width="660" height="565" src="wp-content/uploads/03/post-8-660x565.jpg" class="attachment-green_planet-thumb-bigsquare size-green_planet-thumb-bigsquare wp-post-image" alt="" srcset="wp-content/uploads/03/post-8-660x565.jpg 660w, wp-content/uploads/03/post-8-1320x1130.jpg 1320w" sizes="(max-width: 660px) 100vw, 660px" />
<div class="mask">
</div>
<div class="icons">
<a href="never-stop-appreciating-clean-water/" aria-hidden="true" class="icon-resize-full-alt">
</a>
</div>
</div>
<div class="sc_blogger_item_content entry-content">
<div class="sc_blogger_item_header entry-header">
<div class="post_meta clearfix"> <span class="post_meta_item post_date">
<a href="never-stop-appreciating-clean-water/">Aug 14, 2019</a>
</span>
</div>
<!-- .post_meta -->
<h5 class="sc_blogger_item_title entry-title">
<a href="never-stop-appreciating-clean-water/" rel="bookmark">मृत्यु के बाद क्या होता है<br> Hinduism</a>
</h5>
</div>
<!-- .entry-header -->
</div>
<!-- .entry-content -->
</div>
<!-- .sc_blogger_item -->
</div>
</div>
</div>
<div class="slider_pagination_wrap swiper-pagination">
</div>
</div>
</div>
<!-- /.sc_blogger -->
</div>
</div>
</div>
</div>
<div class="vc_row-full-width vc_clearfix">
</div>
<!-- </.content> -->
</div>
<!-- </.content_wrap> -->
</div>
<!-- </.page_content_wrap> -->

<?php include 'footer.php'
?>
