
<footer class="footer_wrap footer_default scheme_dark"><div class="footer_copyright_wrap scheme_"><div class="footer_copyright_inner"><div class="content_wrap"><div class="copyright_text"><p><a href="https://themeforest.net/user/ancorathemes/portfolio" target="_blank">Bhagwan Shree Laxmi Narayan Dham</a> © 2019. All rights reserved.</p></div></div></div></div></footer><!-- /.footer_wrap --></div><!-- /.page_wrap --></div><!-- /.body_wrap --> <script>(function() {function addEventListener(element,event,handler) {
	if(element.addEventListener) {
		element.addEventListener(event,handler, false);
	} else if(element.attachEvent){
		element.attachEvent('on'+event,handler);
	}
}function maybePrefixUrlField() {
	if(this.value.trim() !== '' && this.value.indexOf('http') !== 0) {
		this.value = "http://" + this.value;
	}
}

var urlFields = document.querySelectorAll('.mc4wp-form input[type="url"]');
if( urlFields && urlFields.length > 0 ) {
	for( var j=0; j < urlFields.length; j++ ) {
		addEventListener(urlFields[j],'blur',maybePrefixUrlField);
	}
}/* test if browser supports date fields */
var testInput = document.createElement('input');
testInput.setAttribute('type', 'date');
if( testInput.type !== 'date') {

	/* add placeholder & pattern to all date fields */
	var dateFields = document.querySelectorAll('.mc4wp-form input[type="date"]');
	for(var i=0; i<dateFields.length; i++) {
		if(!dateFields[i].placeholder) {
			dateFields[i].placeholder = 'YYYY-MM-DD';
		}
		if(!dateFields[i].pattern) {
			dateFields[i].pattern = '[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])';
		}
	}
}

})();</script> 
<script type="text/javascript">var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;</script> 
		<script type="text/javascript">function revslider_showDoubleJqueryError(sliderID) {
					var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
					errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
					errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
					errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
					errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
						jQuery(sliderID).show().html(errorMessage);
				}</script>
				 <link property="stylesheet" rel='stylesheet' id='font-awesome-css'  href='wp-content/plugins/js_composer/lib/font-awesome.min.css?ver=6.0.1' type='text/css' media='all' />
				<link property="stylesheet" rel='stylesheet' id='themepunchboxextcss-css'  href='wp-content/plugins/essential-grid/css/jquery.esgbox.min.css?ver=2.3.2' type='text/css' media='all' /> <script type='text/javascript'>/* <![CDATA[ */
var TRX_ADDONS_STORAGE = {"ajax_url":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","ajax_nonce":"301d502b86","site_url":"http:\/\/ecoplanet.ancorathemes.com","post_id":"331","vc_edit_mode":"0","popup_engine":"magnific","animate_inner_links":"0","user_logged_in":"0","email_mask":"^([a-zA-Z0-9_\\-]+\\.)*[a-zA-Z0-9_\\-]+@[a-z0-9_\\-]+(\\.[a-z0-9_\\-]+)*\\.[a-z]{2,6}$","msg_ajax_error":"Invalid server answer!","msg_magnific_loading":"Loading image","msg_magnific_error":"Error loading image","msg_error_like":"Error saving your like! Please, try again later.","msg_field_name_empty":"The name can't be empty","msg_field_email_empty":"Too short (or empty) email address","msg_field_email_not_valid":"Invalid email address","msg_field_text_empty":"The message text can't be empty","msg_search_error":"Search error! Try again later.","msg_send_complete":"Send message complete!","msg_send_error":"Transmit failed!","ajax_views":"","menu_cache":[".menu_mobile_inner > nav > ul"],"login_via_ajax":"1","msg_login_empty":"The Login field can't be empty","msg_login_long":"The Login field is too long","msg_password_empty":"The password can't be empty and shorter then 4 characters","msg_password_long":"The password is too long","msg_login_success":"Login success! The page should be reloaded in 3 sec.","msg_login_error":"Login failed!","msg_not_agree":"Please, read and check 'Terms and Conditions'","msg_email_long":"E-mail address is too long","msg_email_not_valid":"E-mail address is invalid","msg_password_not_equal":"The passwords in both fields are not equal","msg_registration_success":"Registration success! Please log in!","msg_registration_error":"Registration failed!","scroll_to_anchor":"1","update_location_from_anchor":"0","msg_sc_googlemap_not_avail":"Googlemap service is not available","msg_sc_googlemap_geocoder_error":"Error while geocode address"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_d2c6a3b64e555ee9404ded5267cc587b","fragment_name":"wc_fragments_d2c6a3b64e555ee9404ded5267cc587b","request_timeout":"5000"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var wpgdprcData = {"ajaxURL":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","ajaxSecurity":"1ebdc96904","isMultisite":"","path":"\/","blogId":""};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var GREEN_PLANET_STORAGE = {"ajax_url":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","ajax_nonce":"301d502b86","site_url":"http:\/\/ecoplanet.ancorathemes.com","site_scheme":"scheme_default","user_logged_in":"","mobile_layout_width":"767","mobile_device":"","menu_side_stretch":"1","menu_side_icons":"1","background_video":"","use_mediaelements":"1","comment_maxlength":"1000","admin_mode":"","email_mask":"^([a-zA-Z0-9_\\-]+\\.)*[a-zA-Z0-9_\\-]+@[a-z0-9_\\-]+(\\.[a-z0-9_\\-]+)*\\.[a-z]{2,6}$","strings":{"ajax_error":"Invalid server answer!","error_global":"Error data validation!","name_empty":"The name can&#039;t be empty","name_long":"Too long name","email_empty":"Too short (or empty) email address","email_long":"Too long email address","email_not_valid":"Invalid email address","text_empty":"The message text can&#039;t be empty","text_long":"Too long message text"},"alter_link_color":"#e1a932","button_hover":"default"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var eg_ajax_var = {"url":"http:\/\/ecoplanet.ancorathemes.com\/wp-admin\/admin-ajax.php","nonce":"7a1382dd7e"};
/* ]]> */</script> <script type='text/javascript'>/* <![CDATA[ */
var mc4wp_forms_config = [];
/* ]]> */</script> 
<!--[if lte IE 9]> 
<script type='text/javascript' src='wp-content/plugins/mailchimp-for-wp/assets/js/third-party/placeholders.min.js?ver=4.5.2'></script> <![endif]--> 
<a href="#" class="trx_addons_scroll_to_top trx_addons_icon-up" title="Scroll to top"></a> 
<script type="text/javascript" defer src="wp-content/cache/autoptimize_d58e77cab997b9833fbac9c4a2bd20f6.js"></script></body></html>